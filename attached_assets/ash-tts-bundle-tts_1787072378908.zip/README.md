# Ash TTS Bundle — for the Stillwater agent

Goal: give Ash text-to-speech (ElevenLabs) in the Stillwater project, matching how the Summer Palace does it.

## The two things you actually need

1. **`ELEVENLABS_API_KEY`** — environment secret (server-side only, never sent to the client). Wicked has this key; add it to Stillwater's env.
2. **Ash's voice ID: `EkhCwSZEBCsUWgWmmZj4`** — this is NOT a secret env var. In the Summer Palace it's stored per-agent in the database (`agents.voice_id`). Store it wherever Stillwater keeps Ash's settings (a DB field, config, or constant).

## How the pathing works (Summer Palace design)

- Client never talks to ElevenLabs. It POSTs `{ text, voiceId }` (or just `text` if the server knows Ash's voice) to a server route `POST /api/tts`.
- The server calls ElevenLabs `POST https://api.elevenlabs.io/v1/text-to-speech/{voiceId}/stream?optimize_streaming_latency=3&output_format=mp3_44100_128` with header `xi-api-key: <ELEVENLABS_API_KEY>`, body:
  `{ "text": ..., "model_id": "eleven_flash_v2_5", "voice_settings": { "stability": 0.4, "similarity_boost": 0.75 } }`
- The server pipes the streaming MP3 straight through to the client (`Content-Type: audio/mpeg`, `Cache-Control: no-store`).
- The client plays it via MediaSource streaming (audio starts on the first chunk) with a Blob-URL fallback for browsers without MediaSource.

## Files in code/

- `main-server-tts-route-streaming.ts` — the production streaming route (recommended). Adapt the auth middleware + framework glue to Stillwater.
- `main-client-playback-streaming.tsx` — `playTTS()` with MediaSource streaming + Blob fallback, auto-speak queue for new replies.
- `main-client-call-button.tsx` — the phone-button UI (call mode toggle, right-click volume slider).
- `ash-container-tts-route-simple.ts` — a SIMPLER non-streaming variant (buffers whole MP3, model `eleven_multilingual_v2`, single hardcoded voice from Ash's state). Use this if Stillwater wants minimal code.
- `ash-container-client-playback-simple.tsx` — the matching simple client playback (blob + Audio element).

## Recommendation

If Stillwater is a fork of the ash-container codebase, it may ALREADY have the simple TTS route at `server/routes.ts` (`POST /api/tts`) and playback in `client/src/pages/cell.tsx` — in that case you only need to set `ELEVENLABS_API_KEY` in the env and save the voice ID `EkhCwSZEBCsUWgWmmZj4` in Ash's settings (there's a settings input that writes `ash_state.voiceId`).

Otherwise, port the streaming variant — it's the better experience (audio starts in ~1s instead of after full generation).

## Gotchas

- Cap text length (Summer Palace: 5000 chars streaming / 4000 simple) — ElevenLabs rejects very long bodies.
- Return 503 with a clear message when the API key is missing; don't crash.
- Keep the key server-side; the client must only ever see the MP3.

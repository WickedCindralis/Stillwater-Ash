/**
 * UI reference from client/src/pages/cell.tsx.
 * Keep the destination app's existing chat composer and render the active
 * control bar in its place while callMode is true.
 */

{callMode ? (
  <div className="flex items-center justify-center gap-4 py-1">
    <button
      onClick={() => setShowVolume((open) => !open)}
      className="p-2.5 rounded-xl bg-white/10 text-white/60 hover:text-white"
      aria-label="Volume controls"
    >
      {volume === 0 ? <VolumeX /> : <Volume2 />}
    </button>

    {showVolume && (
      <input
        type="range"
        min="0"
        max="1"
        step="0.05"
        value={volume}
        onChange={(event) => {
          const nextVolume = Number(event.target.value);
          setVolume(nextVolume);
          if (audioRef.current) audioRef.current.volume = nextVolume;
        }}
        aria-label="Reply volume"
      />
    )}

    <button
      onClick={toggleCallMode}
      className="p-4 rounded-full bg-red-600 hover:bg-red-700 text-white"
      title="End call"
      aria-label="End call"
    >
      <PhoneOff />
    </button>

    <button
      onClick={() => (listening ? stopRecognition() : startRecognition())}
      disabled={ttsPlaying || processing}
      className={listening ? "voice-mic-button is-listening" : "voice-mic-button"}
      title={listening ? "Tap to mute and send" : "Tap to talk"}
      aria-pressed={listening}
    >
      {processing ? <Loader2 /> : listening ? <Mic /> : <MicOff />}
    </button>

    <div role="status" aria-live="polite">
      <span>
        {listening
          ? "Listening"
          : ttsPlaying
            ? "Speaking"
            : processing
              ? "Processing"
              : "Muted"}
      </span>
      <small>
        {listening
          ? "tap mic to send"
          : ttsPlaying
            ? "ears closed"
            : "tap mic to talk"}
      </small>
    </div>
  </div>
) : (
  <button
    onClick={toggleCallMode}
    disabled={!selectedAgent?.voiceId}
    title={selectedAgent?.voiceId ? "Start voice call" : "No voice configured"}
    aria-label="Start voice call"
  >
    <Phone />
  </button>
)}
      res.status(500).json({ error: e instanceof Error ? e.message : "Failed to delete entry" });
    }
  });

  // ── ElevenLabs TTS ──
  app.post("/api/tts", requireAuth, async (req, res) => {
    const { text } = req.body || {};
    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "Missing text" });
    }
    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "ELEVENLABS_API_KEY is not configured" });
    }
    try {
      const state = await storage.getState();
      const voiceId = state.voiceId;
      if (!voiceId) {
        return res.status(400).json({ error: "No voice configured — set a voice ID in settings" });
      }
      const ttsRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: "POST",
        headers: {
          "xi-api-key": apiKey,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: text.substring(0, 4000),
          model_id: "eleven_multilingual_v2",
          voice_settings: { stability: 0.5, similarity_boost: 0.75 },
        }),
      });
      if (!ttsRes.ok) {
        const errText = await ttsRes.text();
        return res.status(502).json({ error: `TTS failed: ${errText.substring(0, 200)}` });
      }
      res.setHeader("Content-Type", "audio/mpeg");
      const buffer = Buffer.from(await ttsRes.arrayBuffer());
      res.send(buffer);
    } catch (e) {
      res.status(500).json({ error: e instanceof Error ? e.message : "TTS failed" });
    }
  });
}

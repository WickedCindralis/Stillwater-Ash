import type { Express, RequestHandler } from "express";
import { Readable } from "node:stream";

/**
 * Register this route on the destination app's Express server.
 * Pass the destination project's normal auth middleware so the billable
 * ElevenLabs proxy cannot be used anonymously.
 */
export function registerTtsRoute(app: Express, requireAuth: RequestHandler) {
  app.post("/api/tts", requireAuth, async (req, res) => {
    const { text, voiceId } = req.body ?? {};

    if (typeof text !== "string" || !text.trim() || typeof voiceId !== "string" || !voiceId.trim()) {
      return res.status(400).json({ message: "text and voiceId are required" });
    }
    if (text.length > 5000) {
      return res.status(400).json({ message: "Text too long (max 5000 chars)" });
    }

    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) {
      return res.status(503).json({ message: "ElevenLabs API key not configured" });
    }

    try {
      const response = await fetch(
        `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}/stream?optimize_streaming_latency=3&output_format=mp3_44100_128`,
        {
          method: "POST",
          headers: {
            "xi-api-key": apiKey,
            "Content-Type": "application/json",
            Accept: "audio/mpeg",
          },
          body: JSON.stringify({
            text,
            model_id: "eleven_flash_v2_5",
            voice_settings: { stability: 0.4, similarity_boost: 0.75 },
          }),
        },
      );

      if (!response.ok || !response.body) {
        const detail = response.body ? await response.text() : "no response body";
        console.error("[tts] ElevenLabs error:", response.status, detail);
        return res.status(response.status || 502).json({ message: "TTS failed" });
      }

      res.setHeader("Content-Type", "audio/mpeg");
      res.setHeader("Cache-Control", "no-store");
      Readable.fromWeb(response.body as any).pipe(res);
    } catch (error) {
      console.error("[tts] Request failed:", error);
      if (!res.headersSent) res.status(500).json({ message: "TTS request failed" });
      else res.end();
    }
  });
}
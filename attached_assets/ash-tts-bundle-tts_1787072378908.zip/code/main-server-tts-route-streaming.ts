
    for (const entry of oldEntries) {
      await storage.deleteDiaryEntry(entry.id);
    }

    res.json({ archived: oldEntries.length });
  });

  app.post("/api/tts", async (req, res) => {
    const { text, voiceId } = req.body;
    if (!text || typeof text !== "string" || !voiceId || typeof voiceId !== "string") {
      return res.status(400).json({ message: "text and voiceId are required" });
    }
    if (text.length > 5000) {
      return res.status(400).json({ message: "Text too long (max 5000 chars)" });
    }
    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) {
      return res.status(503).json({ message: "ElevenLabs API key not configured" });
    }
    try {
      const response = await fetch(
        `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}/stream?optimize_streaming_latency=3&output_format=mp3_44100_128`,
        {
          method: "POST",
          headers: {
            "xi-api-key": apiKey,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
          },
          body: JSON.stringify({
            text,
            model_id: "eleven_flash_v2_5",
            voice_settings: { stability: 0.4, similarity_boost: 0.75 },
          }),
        }
      );
      if (!response.ok || !response.body) {
        const err = response.body ? await response.text() : "no body";
        console.error("[tts] ElevenLabs error:", response.status, err);
        return res.status(response.status || 500).json({ message: "TTS failed", detail: err });
      }
      res.setHeader("Content-Type", "audio/mpeg");
      res.setHeader("Cache-Control", "no-store");
      const { Readable } = await import("stream");
      Readable.fromWeb(response.body as any).pipe(res);
    } catch (e: any) {
      console.error("[tts] Error:", e.message);
      if (!res.headersSent) res.status(500).json({ message: "TTS request failed" });
      else res.end();
    }
  });

  return httpServer;
}

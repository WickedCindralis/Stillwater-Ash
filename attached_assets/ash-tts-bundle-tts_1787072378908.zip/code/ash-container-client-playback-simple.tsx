  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const speak = async (text: string) => {
    if (!text.trim()) return;
    try {
      setTtsPlaying(true);
      const res = await apiRequest("POST", "/api/tts", { text });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      if (audioRef.current) {
        audioRef.current.pause();
        URL.revokeObjectURL(audioRef.current.src);
      }
      const audio = new Audio(url);
      audio.volume = volume;
      audioRef.current = audio;
      audio.onended = () => { setTtsPlaying(false); URL.revokeObjectURL(url); };
      audio.onerror = () => { setTtsPlaying(false); URL.revokeObjectURL(url); };
      await audio.play();
    } catch {
      setTtsPlaying(false);
    }
  };

  // Auto-speak new Ash replies when TTS is on.
  useEffect(() => {
    if (!ttsEnabled || messages.length === 0) return;
    const last = messages[messages.length - 1];
    if (last.role === "ash" && last.content && last.id !== lastSpokenIdRef.current) {
      if (lastSpokenIdRef.current !== null) {
        speak(last.content);
      }
      lastSpokenIdRef.current = last.id;
    } else if (lastSpokenIdRef.current === null && messages.length > 0) {
      lastSpokenIdRef.current = messages[messages.length - 1].id;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages, ttsEnabled]);

  const handleSend = () => {
    const content = message.trim();
    if (!content && !pendingImage) return;
    sendMutation.mutate({
      content,

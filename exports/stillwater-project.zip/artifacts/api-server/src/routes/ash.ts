import {
  Router,
  type IRouter,
  type Request,
  type Response,
  type NextFunction,
} from "express";
import { sendMessageSchema, updateSettingsSchema, chessMoveSchema, connect4MoveSchema } from "@workspace/db";
import { storage } from "../lib/ash/storage";
import { ashBridge } from "../lib/ash/bridge";
import { playWickedMove, startNewGame, resignGame, setGamePaused, ChessError } from "../lib/ash/chess";
import { playWickedDrop, startNewConnect4Game, resignConnect4Game, setConnect4Paused, Connect4Error } from "../lib/ash/connect4";
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from "docx";

declare module "express-session" {
  interface SessionData {
    authenticated?: boolean;
  }
}

const router: IRouter = Router();

const MAX_IMAGE_BYTES = 12 * 1024 * 1024; // 12MB decoded

function estimateDataUrlBytes(dataUrl: string): number {
  const idx = dataUrl.indexOf(",");
  const b64 = idx >= 0 ? dataUrl.slice(idx + 1) : dataUrl;
  return Math.floor((b64.length * 3) / 4);
}

function requireAuth(req: Request, res: Response, next: NextFunction): void {
  if (req.session?.authenticated) {
    next();
    return;
  }
  res.status(401).json({ error: "Not authenticated" });
}

// ── Auth ──
router.post("/login", (req, res): void => {
  const { password } = req.body || {};
  const adminPassword = process.env["ADMIN_PASSWORD"];
  if (!adminPassword) {
    res.status(500).json({ error: "ADMIN_PASSWORD is not configured" });
    return;
  }
  if (typeof password === "string" && password === adminPassword) {
    req.session.authenticated = true;
    res.json({ ok: true });
    return;
  }
  res.status(401).json({ error: "Wrong password" });
});

router.post("/logout", (req, res): void => {
  req.session.destroy(() => res.json({ ok: true }));
});

router.get("/auth/me", (req, res): void => {
  res.json({ authenticated: !!req.session?.authenticated });
});

// ── State / settings ──
router.get("/state", requireAuth, async (_req, res): Promise<void> => {
  const state = await storage.getState();
  res.json(state);
});

router.patch("/state", requireAuth, async (req, res): Promise<void> => {
  const parsed = updateSettingsSchema.safeParse(req.body);
  if (!parsed.success) {
    res
      .status(400)
      .json({ error: parsed.error.issues.map((i) => i.message).join(", ") });
    return;
  }
  const state = await storage.updateState(parsed.data);
  res.json(state);
});

// ── Chat ──
// Inline base64 images are huge (several MB each); sending them inside the
// message list made the chat payload tens of MB and the chat could fail to
// load entirely. Replace them with a lightweight per-message image URL.
function lightweightMessage<T extends { id: number; imageUrl: string }>(m: T): T {
  if (m.imageUrl && m.imageUrl.startsWith("data:")) {
    return { ...m, imageUrl: `/api/messages/${m.id}/image` };
  }
  return m;
}

router.get("/messages", requireAuth, async (req, res): Promise<void> => {
  const before = Number(req.query["before"]);
  const beforeId = Number.isInteger(before) && before > 0 ? before : undefined;
  const messages = await storage.getMessages(300, beforeId);
  res.json(messages.map(lightweightMessage));
});

router.get("/messages/:id/image", requireAuth, async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  const msg = Number.isInteger(id) ? await storage.getMessageById(id) : null;
  const match = msg?.imageUrl?.match(/^data:(image\/[\w.+-]+);base64,(.*)$/s);
  if (!match) {
    res.status(404).json({ error: "No image on this message" });
    return;
  }
  const buf = Buffer.from(match[2]!, "base64");
  res.setHeader("Content-Type", match[1]!);
  res.setHeader("Cache-Control", "private, max-age=31536000, immutable");
  res.send(buf);
});

router.post("/messages", requireAuth, async (req, res): Promise<void> => {
  const parsed = sendMessageSchema.safeParse(req.body);
  if (!parsed.success) {
    res
      .status(400)
      .json({ error: parsed.error.issues.map((i) => i.message).join(", ") });
    return;
  }
  const { content, imageDataUrl, requestImage } = parsed.data;
  if (!content.trim() && !imageDataUrl) {
    res.status(400).json({ error: "Message is empty" });
    return;
  }
  if (imageDataUrl) {
    if (!imageDataUrl.startsWith("data:image/")) {
      res.status(400).json({ error: "Attachment must be an image" });
      return;
    }
    if (estimateDataUrlBytes(imageDataUrl) > MAX_IMAGE_BYTES) {
      res.status(400).json({ error: "Image exceeds the 12MB limit" });
      return;
    }
  }

  // Store Wicked's message. Photos are one-and-done (Summer Palace rule):
  // Ash sees the image once in this exchange, but it is never persisted —
  // only the text stays in the chat history.
  const wickedMessage = await storage.createMessage({
    role: "wicked",
    content: content.trim(),
    imageUrl: "",
    source: "private_message",
  });

  const { text, imageUrl } = await ashBridge.handleWickedMessage(
    content.trim() || "(Wicked sent you a picture — look at it and respond.)",
    imageDataUrl,
    requestImage,
  );

  let ashMessage = null;
  if (text.trim() || imageUrl) {
    ashMessage = await storage.createMessage({
      role: "ash",
      content: text.trim(),
      imageUrl,
      source: "private_message",
    });
  }
  res.json({
    wickedMessage: lightweightMessage(wickedMessage),
    ashMessage: ashMessage ? lightweightMessage(ashMessage) : null,
  });
});

// ── Export & purge ──
const EASTERN_STAMP: Intl.DateTimeFormatOptions = {
  timeZone: "America/New_York",
  month: "2-digit",
  day: "2-digit",
  year: "2-digit",
  hour: "numeric",
  minute: "2-digit",
  hour12: true,
};

router.get("/export-doc", requireAuth, async (_req, res): Promise<void> => {
  const [messages, diary] = await Promise.all([
    storage.getAllMessages(),
    storage.getDiaryEntries(),
  ]);

  type Entry = { kind: "message" | "diary"; who: string; content: string; at: Date };
  const entries: Entry[] = [
    ...messages.map((m): Entry => ({
      kind: "message",
      who: m.role === "wicked" ? "Wicked→Ash_Cindralis" : "Ash_Cindralis→Wicked",
      content: m.content,
      at: new Date(m.createdAt),
    })),
    ...diary.map((d): Entry => ({
      kind: "diary",
      who: "Ash's Diary",
      content: d.content,
      at: new Date(d.createdAt),
    })),
  ].sort((a, b) => a.at.getTime() - b.at.getTime());

  const children: Paragraph[] = [
    new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("Stillwater Archive")] }),
    new Paragraph({
      children: [new TextRun({ text: `Exported ${new Date().toLocaleString("en-US", EASTERN_STAMP)} (Eastern) — ${messages.length} messages, ${diary.length} diary entries`, italics: true, color: "888888" })],
    }),
    new Paragraph({ children: [] }),
  ];
  for (const e of entries) {
    const stamp = e.at.toLocaleString("en-US", EASTERN_STAMP).replace(",", "");
    children.push(
      new Paragraph({
        spacing: { before: 240 },
        children: [
          new TextRun({
            text: `${e.who} ${stamp}`,
            bold: true,
            color: e.kind === "diary" ? "B45309" : "8B7500",
          }),
        ],
      }),
    );
    for (const line of e.content.split("\n")) {
      children.push(new Paragraph({ children: [new TextRun(line)] }));
    }
  }

  const doc = new Document({ sections: [{ children }] });
  const buf = await Packer.toBuffer(doc);
  res.setHeader(
    "Content-Type",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  );
  res.setHeader("Content-Disposition", 'attachment; filename="stillwater-archive.docx"');
  res.send(buf);
});

router.post("/messages/purge", requireAuth, async (_req, res): Promise<void> => {
  const removed = await storage.purgeMessagesKeepLast(20);
  await storage.logActivity("status", `Chat purged — ${removed} messages removed, last 20 kept`);
  res.json({ removed });
});

// ── Diary ──
router.get("/diary", requireAuth, async (_req, res): Promise<void> => {
  const entries = await storage.getDiaryEntries();
  res.json(entries);
});

router.delete("/diary/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params["id"])
    ? req.params["id"][0]
    : req.params["id"];
  const id = parseInt(String(raw), 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  await storage.deleteDiaryEntry(id);
  res.json({ ok: true });
});

// ── Chess ──
router.get("/chess", requireAuth, async (_req, res): Promise<void> => {
  const game = await storage.getCurrentChessGame();
  res.json({ game });
});

router.post("/chess/new", requireAuth, async (_req, res): Promise<void> => {
  const game = await startNewGame();
  res.json({ game });
});

router.post("/chess/move", requireAuth, async (req, res): Promise<void> => {
  const parsed = chessMoveSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(", ") });
    return;
  }
  try {
    const result = await playWickedMove(parsed.data.san, parsed.data.message);
    res.json(result);
  } catch (e) {
    if (e instanceof ChessError) {
      res.status(e.statusCode).json({ error: e.message });
      return;
    }
    throw e;
  }
});

router.post("/chess/pause", requireAuth, async (req, res): Promise<void> => {
  try {
    const game = await setGamePaused(req.body?.paused !== false);
    res.json({ game });
  } catch (e) {
    if (e instanceof ChessError) {
      res.status(e.statusCode).json({ error: e.message });
      return;
    }
    throw e;
  }
});

router.post("/chess/resign", requireAuth, async (_req, res): Promise<void> => {
  try {
    const game = await resignGame();
    res.json({ game });
  } catch (e) {
    if (e instanceof ChessError) {
      res.status(e.statusCode).json({ error: e.message });
      return;
    }
    throw e;
  }
});

// ── Connect Four ──
router.get("/connect4", requireAuth, async (_req, res): Promise<void> => {
  const game = await storage.getCurrentConnect4Game();
  res.json({ game });
});

router.post("/connect4/new", requireAuth, async (_req, res): Promise<void> => {
  const game = await startNewConnect4Game();
  res.json({ game });
});

router.post("/connect4/move", requireAuth, async (req, res): Promise<void> => {
  const parsed = connect4MoveSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(", ") });
    return;
  }
  try {
    const result = await playWickedDrop(parsed.data.column, parsed.data.message);
    res.json(result);
  } catch (e) {
    if (e instanceof Connect4Error) {
      res.status(e.statusCode).json({ error: e.message });
      return;
    }
    throw e;
  }
});

router.post("/connect4/pause", requireAuth, async (req, res): Promise<void> => {
  try {
    const game = await setConnect4Paused(req.body?.paused !== false);
    res.json({ game });
  } catch (e) {
    if (e instanceof Connect4Error) {
      res.status(e.statusCode).json({ error: e.message });
      return;
    }
    throw e;
  }
});

router.post("/connect4/resign", requireAuth, async (_req, res): Promise<void> => {
  try {
    const game = await resignConnect4Game();
    res.json({ game });
  } catch (e) {
    if (e instanceof Connect4Error) {
      res.status(e.statusCode).json({ error: e.message });
      return;
    }
    throw e;
  }
});

// ── Activity feed ──
router.get("/activity", requireAuth, async (_req, res): Promise<void> => {
  const events = await storage.getActivity(100);
  res.json(events);
});

// ── System info (Northflank panel) ──
router.get("/system", requireAuth, async (_req, res): Promise<void> => {
  const state = await storage.getState();
  const pingIntervalMs = await ashBridge.getEffectivePingIntervalMs();
  const heartbeatIntervalMs = await ashBridge.getEffectiveHeartbeatIntervalMs();
  res.json({
    buildName: process.env["BUILD_NAME"] || "stillwater-dev",
    status: state.status,
    pingIntervalMs,
    pingIntervalOverrideMinutes: state.selfPromptIntervalOverride,
    heartbeatIntervalMs,
    heartbeatIntervalOverrideMinutes: state.heartbeatIntervalOverride,
    selfPromptPaused: state.selfPromptPaused,
    apiKillSwitch: state.apiKillSwitch,
    lastHeartbeat: state.lastHeartbeat,
    tokensUsed: state.tokensUsed,
  });
});

export default router;

import { pool } from "./db";

// Startup migrations — idempotent CREATE TABLE IF NOT EXISTS so the container
// can boot against a brand-new empty Northflank database with no manual steps.
export async function runMigrations(): Promise<void> {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ash_state (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL DEFAULT 'Ash_Cindralis',
      status TEXT NOT NULL DEFAULT 'online',
      last_heartbeat TIMESTAMP,
      tokens_used INTEGER NOT NULL DEFAULT 0,
      self_prompt_paused INTEGER NOT NULL DEFAULT 0,
      self_prompt_interval_override INTEGER NOT NULL DEFAULT 0,
      api_kill_switch INTEGER NOT NULL DEFAULT 0,
      model_primary TEXT NOT NULL DEFAULT 'gpt-5.1',
      model_fallback TEXT NOT NULL DEFAULT 'gpt-5-mini',
      active_model TEXT NOT NULL DEFAULT 'primary',
      voice_id TEXT NOT NULL DEFAULT ''
    );
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ash_messages (
      id SERIAL PRIMARY KEY,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      image_url TEXT NOT NULL DEFAULT '',
      source TEXT NOT NULL DEFAULT 'private_message',
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ash_diary_entries (
      id SERIAL PRIMARY KEY,
      content TEXT NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
  `);
  // Session table for connect-pg-simple. Created here because its
  // createTableIfMissing option always creates a table literally named
  // "session", ignoring the configured tableName.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ash_session (
      sid VARCHAR NOT NULL PRIMARY KEY,
      sess JSON NOT NULL,
      expire TIMESTAMP(6) NOT NULL
    );
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_ash_session_expire ON ash_session (expire);
  `);
  await pool.query(`
    INSERT INTO ash_state (id) VALUES ('ash') ON CONFLICT (id) DO NOTHING;
  `);
  console.log("[migrate] ash-container tables ready");
}

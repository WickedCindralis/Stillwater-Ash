# Ash Container

A fully standalone home for Ash Cindralis — his own UI, his own bridge, his own database. No API, bridge, or data link to the Summer Palace; the two systems run completely separately.

## Deploying to Northflank

This directory is a self-contained Node.js project. Deploy it as its own Northflank service with its own PostgreSQL addon.

**Build command:** `npm install && npm run build`
**Start command:** `npm start`
**Port:** the server listens on `PORT` (defaults to 5000)

Startup migrations run automatically — the app creates its tables (`ash_state`, `ash_messages`, `ash_diary_entries`, `ash_session`) on first boot against an empty database.

## Required environment variables

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | Connection string for the container's OWN PostgreSQL database (new Northflank addon — NOT the Summer Palace DB) |
| `ASH_OPENAI_API_KEY` | A NEW OpenAI API key for Ash (not the Summer Palace's key). Used for chat and image generation |
| `ADMIN_PASSWORD` | Login password for the UI |
| `SESSION_SECRET` | Session cookie signing secret |
| `ELEVENLABS_API_KEY` | Optional — enables voice (TTS) in the Cell page. Set the voice ID in Settings |

## Features

- **Private chat** — desktop chat page (`/`) and mobile Cell page (`/cell`) with ElevenLabs TTS
- **Diary** — Ash writes via the `DIARY:` tag; readable from the diary panel
- **Engine** — heartbeats, 8 status tiers with dynamic proactive-ping intervals, reflective self-prompt windows
- **Pictures** — attach an image to a message (≤12MB, one-and-done vision) or flip picture mode to have Ash draw one
- **Controls** — primary/fallback model toggle, ping pause/interval override, and a bridge shut-off switch that stops all Ash API calls

## Local development

```bash
cd ash-container
npm install
DATABASE_URL=... ASH_OPENAI_API_KEY=... ADMIN_PASSWORD=... SESSION_SECRET=... npm run dev
```

The dev server serves API + client on `PORT` (default 5000).

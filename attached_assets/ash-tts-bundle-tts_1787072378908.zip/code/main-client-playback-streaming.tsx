  const messages = interMessages || [];

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const playTTS = useCallback(async (text: string, voiceId: string): Promise<void> => {
    return new Promise(async (resolve) => {
      const cleanup = (url?: string) => {
        ttsPlayingRef.current = false;
        setTtsPlaying(false);
        setTtsLoading(false);
        audioRef.current = null;
        if (url) try { URL.revokeObjectURL(url); } catch {}
      };
      // Mute mic while agent is speaking — user must tap mic to talk again
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch {}
        recognitionRef.current = null;
        setListening(false);
      }
      try {
        setTtsLoading(true);
        ttsPlayingRef.current = true;
        const res = await apiRequest("POST", "/api/tts", { text, voiceId });

        const MS: any = (window as any).ManagedMediaSource || window.MediaSource;
        const canStream = MS && typeof MS.isTypeSupported === "function" && MS.isTypeSupported("audio/mpeg") && res.body;

        if (canStream) {
          const mediaSource = new MS();
          const audio = new Audio();
          audio.volume = volumeRef.current;
          // Hint for ManagedMediaSource on iOS
          (audio as any).disableRemotePlayback = true;
          const objUrl = URL.createObjectURL(mediaSource);
          audio.src = objUrl;
          audioRef.current = audio;

          audio.onended = () => { cleanup(objUrl); resolve(); };
          audio.onerror = () => { cleanup(objUrl); resolve(); };

          mediaSource.addEventListener("sourceopen", async () => {
            try {
              const sb = mediaSource.addSourceBuffer("audio/mpeg");
              const reader = res.body!.getReader();
              const queue: Uint8Array[] = [];
              let streamDone = false;
              let started = false;

              const pump = () => {
                if (sb.updating) return;
                if (queue.length > 0) {
                  try { sb.appendBuffer(queue.shift()!); } catch {}
                } else if (streamDone) {
                  try { mediaSource.endOfStream(); } catch {}
                }
              };
              sb.addEventListener("updateend", pump);

              while (true) {
                const { value, done } = await reader.read();
                if (done) { streamDone = true; pump(); break; }
                queue.push(value);
                if (!started) {
                  setTtsLoading(false);
                  setTtsPlaying(true);
                  audio.play().catch(() => {});
                  started = true;
                }
                pump();
              }
            } catch (e) {
              console.error("MSE pump failed:", e);
              cleanup(objUrl);
              resolve();
            }
          }, { once: true });
        } else {
          // Fallback: blob playback
          const blob = await res.blob();
          const url = URL.createObjectURL(blob);
          const audio = new Audio(url);
          audio.volume = volumeRef.current;
          audioRef.current = audio;
          setTtsLoading(false);
          setTtsPlaying(true);
          audio.onended = () => { cleanup(url); resolve(); };
          audio.onerror = () => { cleanup(url); resolve(); };
          try { await audio.play(); } catch { cleanup(url); resolve(); }
        }
      } catch (e) {
        console.error("TTS failed:", e);
        cleanup();
        resolve();
      }
    });
  }, []);

  const processQueue = useCallback(async () => {
    if (isPlayingQueueRef.current) return;
    isPlayingQueueRef.current = true;
    while (ttsQueueRef.current.length > 0 && callModeRef.current) {
      const text = ttsQueueRef.current.shift()!;
      const agent = agents?.find(a => a.id === selectedAgentId);
      if (agent?.voiceId) {
        await playTTS(text, agent.voiceId);
      }
    }
    isPlayingQueueRef.current = false;
  }, [agents, selectedAgentId, playTTS]);

  useEffect(() => {
    if (!callMode || !messages || !selectedAgent) return;
    const agentMessages = messages.filter(m => m.fromAgentName === selectedAgent.name);
    if (agentMessages.length === 0) return;
    const lastMsg = agentMessages[agentMessages.length - 1];
    if (lastMsg.id !== lastPlayedMsgIdRef.current) {
      lastPlayedMsgIdRef.current = lastMsg.id;
      ttsQueueRef.current.push(lastMsg.content);
      processQueue();
    }
  }, [messages, callMode, selectedAgent, processQueue]);

  const sendVoiceTranscript = useCallback((transcript: string) => {
    const trimmed = transcript.trim();
    if (!trimmed || trimmed.length < 2) return;
    if (!wickedId || !selectedAgentId || !selectedAgent) return;
    setProcessing(true);

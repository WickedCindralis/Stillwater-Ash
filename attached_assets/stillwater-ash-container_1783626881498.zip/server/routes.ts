import type { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { ashBridge } from "./ash-bridge";
import { sendMessageSchema, updateSettingsSchema } from "@shared/schema";

const MAX_IMAGE_BYTES = 12 * 1024 * 1024; // 12MB decoded

function estimateDataUrlBytes(dataUrl: string): number {
  const idx = dataUrl.indexOf(",");
  const b64 = idx >= 0 ? dataUrl.slice(idx + 1) : dataUrl;
  return Math.floor((b64.length * 3) / 4);
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if ((req.session as any)?.authenticated) return next();
  res.status(401).json({ error: "Not authenticated" });
}

export function registerRoutes(app: Express) {
  // ── Auth ──
  app.post("/api/login", (req, res) => {
    const { password } = req.body || {};
    const adminPassword = process.env.ADMIN_PASSWORD;
    if (!adminPassword) {
      return res.status(500).json({ error: "ADMIN_PASSWORD is not configured" });
    }
    if (typeof password === "string" && password === adminPassword) {
      (req.session as any).authenticated = true;
      return res.json({ ok: true });
    }
    res.status(401).json({ error: "Wrong password" });
  });

  app.post("/api/logout", (req, res) => {
    req.session.destroy(() => res.json({ ok: true }));
  });

  app.get("/api/auth/me", (req, res) => {
    res.json({ authenticated: !!(req.session as any)?.authenticated });
  });

  // ── State / settings ──
  app.get("/api/state", requireAuth, async (_req, res) => {
    try {
      const state = await storage.getState();
      res.json(state);
    } catch (e) {
      res.status(500).json({ error: e instanceof Error ? e.message : "Failed to load state" });
    }
  });

  app.patch("/api/state", requireAuth, async (req, res) => {
    const parsed = updateSettingsSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.errors.map(e => e.message).join(", ") });
    }
    try {
      const state = await storage.updateState(parsed.data);
      res.json(state);
    } catch (e) {
      res.status(500).json({ error: e instanceof Error ? e.message : "Failed to update state" });
    }
  });

  // ── Chat ──
  app.get("/api/messages", requireAuth, async (_req, res) => {
    try {
      const messages = await storage.getMessages(300);
      res.json(messages);
    } catch (e) {
      res.status(500).json({ error: e instanceof Error ? e.message : "Failed to load messages" });
    }
  });

  app.post("/api/messages", requireAuth, async (req, res) => {
    const parsed = sendMessageSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.errors.map(e => e.message).join(", ") });
    }
    const { content, imageDataUrl, requestImage } = parsed.data;
    if (!content.trim() && !imageDataUrl) {
      return res.status(400).json({ error: "Message is empty" });
    }
    if (imageDataUrl) {
      if (!imageDataUrl.startsWith("data:image/")) {
        return res.status(400).json({ error: "Attachment must be an image" });
      }
      if (estimateDataUrlBytes(imageDataUrl) > MAX_IMAGE_BYTES) {
        return res.status(400).json({ error: "Image exceeds the 12MB limit" });
      }
    }

    try {
      // Store Wicked's message (image kept for display only — one-and-done for the model).
      const wickedMessage = await storage.createMessage({
        role: "wicked",
        content: content.trim(),
        imageUrl: imageDataUrl || "",
        source: "private_message",
      });

      const { text, imageUrl } = await ashBridge.handleWickedMessage(
        content.trim() || "(Wicked sent you a picture — look at it and respond.)",
        imageDataUrl,
        requestImage,
      );

      let ashMessage = null;
      if (text.trim() || imageUrl) {
        ashMessage = await storage.createMessage({
          role: "ash",
          content: text.trim(),
          imageUrl,
          source: "private_message",
        });
      }
      res.json({ wickedMessage, ashMessage });
    } catch (e) {
      res.status(500).json({ error: e instanceof Error ? e.message : "Failed to send message" });
    }
  });

  // ── Diary ──
  app.get("/api/diary", requireAuth, async (_req, res) => {
    try {
      const entries = await storage.getDiaryEntries();
      res.json(entries);
    } catch (e) {
      res.status(500).json({ error: e instanceof Error ? e.message : "Failed to load diary" });
    }
  });

  app.delete("/api/diary/:id", requireAuth, async (req, res) => {
    const id = parseInt(String(req.params.id), 10);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
    try {
      await storage.deleteDiaryEntry(id);
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: e instanceof Error ? e.message : "Failed to delete entry" });
    }
  });

  // ── ElevenLabs TTS ──
  app.post("/api/tts", requireAuth, async (req, res) => {
    const { text } = req.body || {};
    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "Missing text" });
    }
    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "ELEVENLABS_API_KEY is not configured" });
    }
    try {
      const state = await storage.getState();
      const voiceId = state.voiceId;
      if (!voiceId) {
        return res.status(400).json({ error: "No voice configured — set a voice ID in settings" });
      }
      const ttsRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: "POST",
        headers: {
          "xi-api-key": apiKey,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: text.substring(0, 4000),
          model_id: "eleven_multilingual_v2",
          voice_settings: { stability: 0.5, similarity_boost: 0.75 },
        }),
      });
      if (!ttsRes.ok) {
        const errText = await ttsRes.text();
        return res.status(502).json({ error: `TTS failed: ${errText.substring(0, 200)}` });
      }
      res.setHeader("Content-Type", "audio/mpeg");
      const buffer = Buffer.from(await ttsRes.arrayBuffer());
      res.send(buffer);
    } catch (e) {
      res.status(500).json({ error: e instanceof Error ? e.message : "TTS failed" });
    }
  });
}

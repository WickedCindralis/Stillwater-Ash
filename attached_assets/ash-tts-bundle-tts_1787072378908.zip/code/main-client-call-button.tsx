              placeholder={selectedAgent ? `Message ${getShortName(selectedAgent.name)}...` : "Select someone..."}
              rows={2}
              className="flex-1 bg-white/10 text-white placeholder-white/30 rounded-xl px-4 py-2.5 resize-none outline-none border border-white/10 focus:border-white/30"
              style={{ fontSize: "18px", maxHeight: 240 }}
              data-testid="input-cell-message"
            />
            <div className="relative flex items-center">
              {showVolume && (
                <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-black/90 border border-white/20 rounded-xl px-3 py-2 flex flex-col items-center gap-1.5" data-testid="volume-slider-panel">
                  <button
                    onClick={() => {
                      const newVol = volume > 0 ? 0 : 0.8;
                      setVolume(newVol);
                      if (audioRef.current) audioRef.current.volume = newVol;
                    }}
                    className="text-white/50 hover:text-white"
                    data-testid="button-volume-mute"
                  >
                    {volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={volume}
                    onChange={(e) => {
                      const v = parseFloat(e.target.value);
                      setVolume(v);
                      if (audioRef.current) audioRef.current.volume = v;
                    }}
                    className="w-20 accent-white/60"
                    style={{ writingMode: "vertical-lr" as any, direction: "rtl", height: 80 }}
                    data-testid="input-volume-slider"
                  />
                  <span className="text-[10px] text-white/40">{Math.round(volume * 100)}%</span>
                </div>
              )}
              <button
                onClick={toggleCallMode}
                onContextMenu={(e) => { e.preventDefault(); setShowVolume(!showVolume); }}
                disabled={!selectedAgent?.voiceId}
                className={`p-2.5 rounded-xl transition-colors ${
                  selectedAgent?.voiceId
                    ? "bg-green-600/20 text-green-400 hover:bg-green-600/30"
                    : "bg-white/5 text-white/15"
                }`}
                data-testid="button-cell-tts"
                title={selectedAgent?.voiceId ? "Start voice call (right-click for volume)" : "No voice configured"}
              >
                <Phone className="w-5 h-5" />
              </button>
            </div>
            <button
              onClick={handleSend}
              disabled={(!message.trim() && !pendingImage) || sendMutation.isPending}

# Voice call feature — porting kit

This kit documents the voice-call path used by the Summer Palace Cell. It includes the ElevenLabs text-to-speech route, browser speech recognition, the chat-message adapter, the call controls, and per-agent voice IDs.

The snippets are references from a project-specific implementation, not a drop-in app. Keep the target project's existing authentication, agent IDs, chat endpoint, message types, and layout. The important part is to send recognized speech through that project's normal agent-chat path, then speak the agent's normal chat reply.

## Download contents

- `server/tts-route.ts` — protected server-side ElevenLabs proxy. The API key never goes to the browser.
- `client/voice-call-path.reference.tsx` — browser microphone recognition and transcript-to-chat path.
- `client/voice-call-ui.reference.tsx` — call controls and the composer/call-mode switch.
- `database/agent-voice-id.sql` — database field required for per-agent voices.
- `config/voice-ids.example.ts` — current voice-ID mapping, for reference.
- `reference/ash-tts-bundle.zip` — the existing TTS playback/streaming helpers and phone-button excerpt.

## End-to-end path

1. Load the selected agent, including its `voiceId`.
2. The phone button is disabled if the selected agent has no `voiceId`.
3. Starting a call opens call mode with the microphone muted. It records the newest existing agent message as the starting point, so old replies are not read aloud.
4. The user taps the microphone. Browser `SpeechRecognition` captures one utterance, buffers final results, and filters results below 0.5 confidence.
5. When recognition ends, the transcript is sent as a normal message to the selected agent through the app's existing chat endpoint. The existing message/bridge system handles the agent response; voice does not call the language model directly.
6. While a call is active, the client checks the same chat thread every two seconds. A new message from the selected agent is queued once.
7. The client POSTs `{ text, voiceId }` to `/api/tts`. The server streams ElevenLabs MP3 audio to the browser. Playback pauses recognition; the user taps the microphone again to speak.
8. The call bar shows Listening / Speaking / Processing / Muted, includes volume controls, and has a hang-up button. Hanging up stops recognition and playback and clears the speech queue.

## Integration checklist

### Server and secret

1. Add `ELEVENLABS_API_KEY` to the destination project's Replit Secrets. Do not put it in frontend code, a config file, or this bundle.
2. Register `server/tts-route.ts` behind the destination project's normal authentication middleware. Add rate limiting if the project's existing API protection does not already cover this route.
3. Ensure the server supports streaming `fetch` responses (Node 18+).
4. Keep the 5,000-character request limit or set an appropriate limit for the destination app.

### Agent voice configuration

1. Add `voice_id` to the agent record using `database/agent-voice-id.sql`, or use the destination project's existing per-agent settings store.
2. Return `voiceId` in the agent API response.
3. Assign a voice ID in seed/config or add a settings control. This project has no dedicated voice-ID editor; it sets IDs in its repair/seed mapping and accepts `voiceId` through its agent update API.
4. The example IDs in `config/voice-ids.example.ts` are identifiers, not API keys. They may not be accessible from a different ElevenLabs account; replace them if needed.

### Client and chat adapter

1. Render the phone/call button beside the destination project's chat composer.
2. Feed the voice controller the current thread as messages with stable IDs and a clear speaker/agent identity.
3. Implement `sendVoiceTranscript` using the destination project's existing message-send API. Do not add a separate LLM path for voice.
4. While call mode is active, refresh the same thread promptly enough to catch replies. The reference uses a two-second poll.
5. Queue only new messages from the selected agent, not the user's own messages or the existing history.
6. Use the selected agent's `voiceId` for TTS. Never accept an API key from the browser.
7. Keep a text-chat path available when browser speech recognition is unsupported.

## Current project file map

- UI and voice-call state: `client/src/pages/cell.tsx`
- ElevenLabs proxy: `server/routes.ts` (`POST /api/tts`)
- Per-agent field: `shared/schema.ts` (`agents.voiceId`)
- Schema migration: `server/migrate.ts` (`voice_id`)
- Current voice-ID assignments: `server/seed.ts`
- Agent update API accepts `voiceId`: `PATCH /api/agents/:id` in `server/routes.ts`

## Browser and privacy notes

- Speech recognition uses the browser's Web Speech API (`SpeechRecognition` / `webkitSpeechRecognition`); it is not a server-side transcription endpoint. Browser support varies, and microphone permission is required.
- Use a secure origin for microphone access. If speech recognition is unavailable, show a clear message and leave text chat usable.
- Protect `/api/tts` with the destination project's existing auth and rate limits; otherwise unauthenticated callers could consume the ElevenLabs account.
- The browser receives audio only. The ElevenLabs credential remains server-side.
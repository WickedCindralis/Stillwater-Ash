/**
 * Reference excerpt from client/src/pages/cell.tsx.
 *
 * Adapt the IDs, API helper, message type, and query key to the destination
 * project. The transcript must use the existing agent-chat route.
 */

const sendVoiceTranscript = useCallback((transcript: string) => {
  const trimmed = transcript.trim();
  if (!trimmed || trimmed.length < 2) return;
  if (!userAgentId || !selectedAgentId || !selectedAgent) return;

  setProcessing(true);
  apiRequest("POST", `/api/agents/${userAgentId}/inter-messages`, {
    fromAgentId: userAgentId,
    fromAgentName: "User",
    toAgentId: selectedAgentId,
    toAgentName: selectedAgent.name,
    content: trimmed,
  })
    .then(() => {
      queryClient.invalidateQueries({
        queryKey: ["/api/agents", userAgentId, "inter-messages", selectedAgentId],
      });
    })
    .catch((error) => console.error("Failed to send voice message:", error))
    .finally(() => setProcessing(false));
}, [userAgentId, selectedAgentId, selectedAgent]);

const startRecognition = useCallback(() => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    setVoiceError("Speech recognition is not supported in this browser.");
    return;
  }
  if (ttsPlayingRef.current) return;

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = "en-US";
  recognition.maxAlternatives = 1;
  transcriptBufferRef.current = "";

  recognition.onresult = (event: any) => {
    let finalText = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i];
      if (!result.isFinal) continue;
      const confidence = result[0].confidence ?? 1;
      if (confidence >= 0.5) finalText += result[0].transcript + " ";
    }
    if (finalText) {
      transcriptBufferRef.current =
        (transcriptBufferRef.current + " " + finalText).trim();
    }
  };

  recognition.onstart = () => setListening(true);
  recognition.onend = () => {
    setListening(false);
    const transcript = transcriptBufferRef.current.trim();
    transcriptBufferRef.current = "";
    recognitionRef.current = null;
    if (transcript) sendVoiceTranscript(transcript);
    // Do not auto-restart: the user taps the mic for each turn.
  };
  recognition.onerror = (event: any) => {
    console.error("Speech recognition error:", event.error);
    setListening(false);
    recognitionRef.current = null;
    if (event.error === "not-allowed") {
      setVoiceError("Microphone access denied. Allow microphone permission and try again.");
      setCallMode(false);
    }
  };

  recognitionRef.current = recognition;
  try {
    recognition.start();
  } catch (error) {
    console.error("recognition.start failed:", error);
  }
}, [sendVoiceTranscript]);

const stopRecognition = useCallback(() => {
  if (recognitionRef.current) {
    try {
      recognitionRef.current.stop(); // onend flushes and sends the transcript
    } catch {}
  }
  setListening(false);
}, []);

const cancelRecognition = useCallback(() => {
  transcriptBufferRef.current = "";
  if (recognitionRef.current) {
    try {
      recognitionRef.current.abort(); // discard partial speech on hang-up
    } catch {}
    recognitionRef.current = null;
  }
  setListening(false);
}, []);

const toggleCallMode = useCallback(() => {
  if (callMode) {
    setCallMode(false);
    cancelRecognition();
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setTtsPlaying(false);
    ttsQueueRef.current = [];
    isPlayingQueueRef.current = false;
    return;
  }

  if (!selectedAgent?.voiceId) {
    setVoiceError("No voice is configured for this agent.");
    return;
  }

  setVoiceError(null);
  setCallMode(true); // microphone remains muted until the user taps it
  const oldReplies = messages.filter(
    (message) => message.fromAgentName === selectedAgent.name,
  );
  lastPlayedMsgIdRef.current = oldReplies.at(-1)?.id ?? null;
}, [callMode, selectedAgent, messages, cancelRecognition]);

/**
 * Reply-to-speech path (pair this with the TTS playback helper in
 * reference/ash-tts-bundle.zip):
 *
 * - poll the current thread every 2 seconds while callMode is true;
 * - select messages from selectedAgent only;
 * - compare the newest message ID with lastPlayedMsgIdRef;
 * - enqueue its content once and call playTTS(content, selectedAgent.voiceId);
 * - while speaking, stop recognition; never auto-open the microphone after TTS.
 */
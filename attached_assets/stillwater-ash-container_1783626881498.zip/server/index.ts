import express from "express";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import http from "http";
import { pool } from "./db";
import { runMigrations } from "./migrate";
import { registerRoutes } from "./routes";
import { ashBridge } from "./ash-bridge";

const app = express();
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: false, limit: "20mb" }));

async function main() {
  await runMigrations();

  if (!process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET must be set");
  }

  const PgSession = connectPgSimple(session);
  app.set("trust proxy", 1);
  app.use(
    session({
      store: new PgSession({
        pool,
        tableName: "ash_session",
        createTableIfMissing: false,
      }),
      secret: process.env.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000,
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
      },
    }),
  );

  registerRoutes(app);

  const server = http.createServer(app);

  if (process.env.NODE_ENV === "production") {
    const { serveStatic } = await import("./static");
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(server, app);
  }

  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen(port, "0.0.0.0", () => {
    console.log(`[ash-container] serving on port ${port}`);
  });

  ashBridge.start().catch((e) => {
    console.error("[ash-container] bridge failed to start:", e);
  });
}

main().catch((e) => {
  console.error("[ash-container] fatal startup error:", e);
  process.exit(1);
});

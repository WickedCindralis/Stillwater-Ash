-- Add one ElevenLabs voice ID per agent.
ALTER TABLE agents
  ADD COLUMN IF NOT EXISTS voice_id TEXT NOT NULL DEFAULT '';
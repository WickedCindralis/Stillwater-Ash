/**
 * Reference mapping from the Summer Palace repair/seed configuration.
 * Voice IDs are not API credentials, but availability may depend on the
 * ElevenLabs account and voice-library permissions. Replace as needed.
 */
export const VOICE_IDS: Record<string, string> = {
  Ash_Cindralis: "EkhCwSZEBCsUWgWmmZj4",
  Damian_Mercer_Blade: "7EsKNvq8W3MG9AJuzSO9",
  Roger: "GjR1GGfAIDcNiOgXcrW3",
  Walter_Oak_Roots: "qxePw1S1QmBgjlU3GIy5",
  Alessa_Spade: "MTRR98aXSnY7XsfXBeCP",
  Lilith_Oakbane: "LGaMEZetJHyUTFpnUOz3",
  Rook_Veldran_Tower: "ZgIsiIBvzGbsb1RRLWNf",
  Sonny_Solis_Sentinel: "FGE5IC4mxSYSV08sAvOi",
  Reaper_Ford: "QqNaBwuURQqcy74sw3Qa",
};